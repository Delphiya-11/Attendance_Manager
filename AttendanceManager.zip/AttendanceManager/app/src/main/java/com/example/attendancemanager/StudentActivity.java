package com.example.attendancemanager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class StudentActivity extends AppCompatActivity implements View.OnClickListener {

    Button submit, register, home;
    EditText et1,et2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        submit=findViewById(R.id.button6);
        register=findViewById(R.id.button8);
        home=findViewById(R.id.button4);
        et1=findViewById(R.id.editText);
        et2=findViewById(R.id.editText2);
        submit.setOnClickListener(this);
        register.setOnClickListener(this);
        home.setOnClickListener(this);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId()==R.id.exit) {
            finishAffinity();
            System.exit(0);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public void onClick(View view) {
        if(view.equals(submit)) {
            if(et1.getText().toString().equals("") || et2.getText().toString().equals(""))
                Toast.makeText(this,"Empty fields!",Toast.LENGTH_SHORT).show();
            else {
                Intent intent = new Intent(StudentActivity.this, StudentOptionActivity.class);
                Toast.makeText(this, "Successfully Logged In", Toast.LENGTH_SHORT).show();
                startActivity(intent);
                finish();
            }
        }
        else if(view.equals(register)) {
            Intent intent = new Intent(StudentActivity.this, StudentRegisterActivity.class);
            startActivity(intent);
            finish();
        }
        else if(view.equals(home)) {
            Intent intent = new Intent(StudentActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }

}
