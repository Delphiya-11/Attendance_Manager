package com.example.attendancemanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class StudentRegisterActivity extends AppCompatActivity implements View.OnClickListener {

    Button b1,b2;
    EditText name,roll,sem,user,pwd;
    boolean checked, checked1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_register);

        b1=findViewById(R.id.button12);
        b2=findViewById(R.id.button13);
        user=findViewById(R.id.editText);
        pwd=findViewById(R.id.editText2);
        name=findViewById(R.id.editText3);
        roll=findViewById(R.id.editText4);
        sem=findViewById(R.id.editText6);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        if(item.getItemId()==R.id.exit) {
            finishAffinity();
            System.exit(0);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public void onClick(View view) {

        if(view.equals(b1)) {
            if(checked==false || checked1==false || name.getText().toString().equals("") || roll.getText().toString().equals("") || sem.getText().toString().equals("") || user.getText().toString().equals("") || pwd.getText().toString().equals(""))
                Toast.makeText(this,"Empty fields!",Toast.LENGTH_SHORT).show();
            else {
                Intent intent = new Intent(StudentRegisterActivity.this, SplashRegisterActivity.class);
                startActivity(intent);
                finish();
            }
        }
        else if(view.equals(b2)) {
            Intent intent = new Intent(StudentRegisterActivity.this, StudentActivity.class);
            startActivity(intent);
            finish();
        }

    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        checked = ((RadioButton) view).isChecked();

    }

    public void onRadioButtonClicked1(View view) {
        // Is the button now checked?
        checked1 = ((RadioButton) view).isChecked();

    }

}
